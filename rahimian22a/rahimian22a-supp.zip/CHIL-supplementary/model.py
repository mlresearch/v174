import numpy as np
from pathlib import Path
import os
import matplotlib.pyplot as plt
import pandas as pd 

import torch # For building the networks 
import torch.nn as nn
import torchtuples as tt # Some useful functions
import torch.nn.functional as F 
import torch.optim as optim

from pycox.models import CoxTime, CoxCC, CoxPH, DeepHitSingle
from pycox.models.cox_time import MLPVanillaCoxTime

from pycox.evaluation import EvalSurv
from pycox.datasets import metabric, gbsg, support
from lifelines import KaplanMeierFitter

from opacus import PrivacyEngine

import data_preprocess as dataprep
import federated as fd

np.random.seed(1234)
_ = torch.manual_seed(123)
path_runs = '' 
# num_durations = 30

def get_target(df):
    return (df['duration'].values, df['event'].values)

def deephit_data_transform(df_y_train, df_y_test, num_durations):
    """transform labels according to DeepHit model (Discretizes)
    """
    labtrans = DeepHitSingle.label_transform(num_durations)
    y_train = labtrans.fit_transform(*get_target(df_y_train))
    y_val = labtrans.transform(*get_target(df_y_test))

    return y_train, y_val, labtrans

def deephit_model(in_features, labtrans, opt, 
                  alpha=0.2, lr=0.0001):
    """returns DeepHit model for given input
    !PAY ATTENTION! out_features is just an int equal to num_durations
    """
    num_nodes = [32, 32]
    out_features = labtrans.out_features
    batch_norm = False
    dropout = 0.1
    net = tt.practical.MLPVanilla(in_features, num_nodes,
            out_features, batch_norm, dropout)
    if opt == "adam":
        optimizer = optim.Adam(net.parameters(), lr=lr)
    elif opt == "sgd":
        optimizer = optim.SGD(net.parameters(), lr=lr)

    model = DeepHitSingle(net,
                        optimizer,
                        alpha=alpha,
                        sigma=0.1,
                        duration_index=labtrans.cuts)
    return model, optimizer

def coxtime_data_transform(df_y_train, df_y_test):
    labtrans = CoxTime.label_transform()
    y_train = labtrans.fit_transform(*get_target(df_y_train))
    y_val = labtrans.transform(*get_target(df_y_test))
    return y_train, y_val, labtrans

def coxtime_model(in_features, labtrans, opt, lr=0.0001):
    num_nodes = [32, 32]
    batch_norm = False
    dropout = 0.1
    net = MLPVanillaCoxTime(in_features, num_nodes, batch_norm,
            dropout)
    if opt == "adam":
        optimizer = optim.Adam(net.parameters(), lr=lr)
    elif opt == "sgd":
        optimizer = optim.SGD(net.parameters(), lr=lr)
    model = CoxTime(net, optimizer, labtrans=labtrans)
    return model, optimizer

def coxcc_data_transform(df_y_train, df_y_test):
    y_train = get_target(df_y_train)
    y_val = get_target(df_y_test)
    return y_train, y_val

def coxcc_model(in_features, opt, lr=0.0001):
    num_nodes = [32, 32]
    out_features = 1
    batch_norm = False
    dropout = 0.1
    output_bias = False

    net = tt.practical.MLPVanilla(in_features, num_nodes,
            out_features, batch_norm,
            dropout,
            output_bias=output_bias)
    if opt == "adam":
        optimizer = optim.Adam(net.parameters(), lr=lr)
    elif opt == "sgd":
        optimizer = optim.SGD(net.parameters(), lr=lr)
    model = CoxCC(net, optimizer)
    return model, optimizer

def coxph_data_transform(df_y_train, df_y_test):
    y_train = get_target(df_y_train)
    y_val = get_target(df_y_test)
    return y_train, y_val

def coxph_model(in_features, opt, lr=0.0001):
    num_nodes = [32, 32]
    out_features = 1
    batch_norm = False
    dropout = 0.1
    output_bias = False

    net = tt.practical.MLPVanilla(in_features, num_nodes,
            out_features, batch_norm,
            dropout,
            output_bias=output_bias)
    if opt == "adam":
        optimizer = optim.Adam(net.parameters(), lr=lr)
    elif opt == "sgd":
        optimizer = optim.SGD(net.parameters(), lr=lr)
    model = CoxPH(net, optimizer)
    return model, optimizer

def initialize(dataset, model_name, opt, lr=0.0001, num_durations=30):
    """
    initialized models.

    Can be used for both federated and centralized setting. 
    takes dataset and model names as str, and returns the corresponding 
    initialized model and optimizer, and transformed labels and 
    training/test data
    
    Args:
        dataset: str, dataset name metabric, gbsg, support
        model_name: str, model name deephit, coxtime, coxph, coxcc
        optim: str, optimizer to be chosen. adam or sgd
        lr: float, the learning rate set for the optimizer
        num_durations: int, used to discretize the output of DeepHit model
    """
    x_train, df_y_train, x_test, df_y_test = dataprep.data(dataset)
    print(x_train[0])

    in_features = x_train.shape[1]
    labtrans = []

    if model_name == "deephit":
        y_train, y_val, labtrans = deephit_data_transform(
                df_y_train,
                df_y_test,
                num_durations= num_durations)
        model, optimizer = deephit_model(
                in_features,
                labtrans,
                opt,
                alpha=0.2,
                lr=lr)
    elif model_name == "coxtime":
        y_train, y_val, labtrans = coxtime_data_transform(
                df_y_train,
                df_y_test)
        model, optimizer  = coxtime_model(
                in_features,
                labtrans,
                opt,
                lr=lr)
    elif model_name == "coxcc":
        y_train, y_val = coxcc_data_transform(
                df_y_train,
                df_y_test)
        model, optimizer = coxcc_model(
                in_features,
                opt,
                lr=lr)
    elif model_name == "coxph":
        y_train, y_val = coxph_data_transform(
                df_y_train,
                df_y_test)
        model, optimizer = coxph_model(
                in_features,
                opt,
                lr=lr)
    else:
        raise ValueError("Please choose a valid model and dataset")

    return x_train, y_train, x_test, y_val, df_y_test, labtrans, model, optimizer


def fd_initialize(model_name, global_model, num_clients, in_features,
                  labtrans, opt, lr=0.0001):
    """
    Initialized client models for federated setting with num_clients
    Args:
        model: str, name of the model to be used, deephit, coxtime, 
        coxph, coxcc
        global_model: pycox object, global model created as server
        num_client: int, how many clients participate in total 
    """

    client_models = []
    for i in range(num_clients):
        if model_name == "deephit":
            model, optimizer = deephit_model(
                    in_features,
                    labtrans,
                    opt,
                    alpha=0.2,
                    lr=lr)
        elif model_name == "coxtime":
            model, optimizer  = coxtime_model(
                    in_features,
                    labtrans,
                    opt,
                    lr=lr)
        elif model_name == "coxcc":
            model, optimizer = coxcc_model(
                    in_features,
                    opt,
                    lr=lr)
        elif model_name == "coxph": 
            model, optimizer = coxph_model(
                    in_features,
                    opt,
                    lr=lr)
        else:
            raise ValueError("Please choose a valid model name")

        model.net.load_state_dict(global_model.net.state_dict())
        client_models.append(model)

    return client_models




def run(args):
    x_train, df_y_train, x_test, df_y_test = dataprep.data(args.dataset)
    print(x_train[0])

    if args.model == "deephit":
        y_train, y_val, model = deephit(df_y_train, df_y_test,
                x_train.shape[1],
                alpha=0.2,
                lr=0.0001,
                num_durations=350)

    elif args.model == "coxtime":
        y_train, y_val, model = coxtime(df_y_train, df_y_test,
                x_train.shape[1], lr=0.0001)

    elif args.model == "coxcc":
        y_train, y_val, model = coxcc(df_y_train,
                df_y_test,
                in_features=x_train.shape[1],
                lr=0.0001) 
    else:
        y_train, y_val, model = coxph(df_y_train,
                df_y_test,
                in_features=x_train.shape[1],
                lr=0.0001) 

    train = (x_train, y_train)
    val = (x_test, y_val)
    # val = (x_val, y_val)

    # We don't need to transform the test labels
    durations_test, events_test = get_target(df_y_test)

    epochs = 100
    batch_size = 64
    callbacks = [tt.callbacks.EarlyStopping()]
    log = model.fit(x_train, y_train, batch_size, epochs,
            callbacks, val_data=val)

    if args.model != "deephit":
        _ = model.compute_baseline_hazards()

    time_grid = np.linspace(durations_test.min(),
            durations_test.max(), 350)

    surv = model.predict_surv_df(x_test)
    ev = EvalSurv(surv, durations_test, events_test,
            censor_surv='km')
    bestc = ev.concordance_td('antolini')
    print("test concordance index:",ev.concordance_td('antolini'))
    print("negative binomial ll:", ev.integrated_nbll(time_grid))
    print("integrated brier score:", ev.integrated_brier_score(time_grid))
    # # model.save_net(PATH + '/' + path_str)
