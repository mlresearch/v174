import os
import random
import numpy as np
from copy import deepcopy
import torch 

def server_aggregate_delta(global_model, client_models, delta, client_idx, 
        pp_norm, max_norm, m):
    """
    Takes global model and client_models and computes the aggregate. Note that 
    client_models that were used during the last round of training only 
    contain $\Delta \theta$, the difference to global model parameters of the
    previous round. Here to calculate the aggregate we have:
    $\theta^{t+1} = \theta^{t} + 1/|client_idx|(\Sigma \Delta\theta)$
    Args:
        client_idx = IDs of the clients chosen to train on their local model
        max_norm = clipping threshold
        m = noise multiplier. The Gaussian adds a noise with std = ~m*max_norm
    """
    num_selected = len(client_idx)
    sigma = (max_norm*m)/num_selected
    
    global_dict = global_model.net.state_dict()
    #compute average of aggregates
    for k in delta.keys():
        delta[k] = torch.stack(
                [client_models[i].net.state_dict()[k].float() for i in client_idx], 0).mean(0)
        #add Gaussian noise to the average of aggregates
        delta[k] += np.random.normal(0, sigma, global_dict[k].numpy().shape)
    #post processing with clipping
    total_norm = torch.norm(torch.stack([torch.norm(delta[k], 2) for k in delta.keys()]), 2)
    clip_coef = pp_norm / (total_norm + 1e-6)
    clip_coef_clamped = torch.clamp(clip_coef, max=1.0)
    for k in delta.keys():
        delta[k] = delta[k].mul(clip_coef_clamped)

    for k in global_dict.keys():
        global_dict[k] += delta[k]
    global_model.net.load_state_dict(global_dict)
    for model in client_models:
        model.net.load_state_dict(global_model.net.state_dict())


def server_aggregate(global_model, client_models, max_norm, m=1):
    """
    after local training is done, takes the average of local
    parameters, sets as global model parameter, shares the new
    global model parameters with clients
    To calculate the aggregate we use:
    $\theta^{t+1} = \theta^{t} + 1/|client_models|(\Sigma \Delta\theta)$
    """
    global_dict = global_model.net.state_dict()
    for k in global_dict.keys():
        global_dict[k] = torch.stack(
                [client_models[i].net.state_dict()[k].float() for i in range(len(client_models))], 0).mean(0)
        global_dict[k] += np.random.normal(0, max_norm*m, global_dict[k].numpy().shape)
    global_model.net.load_state_dict(global_dict)
    for model in client_models:
        model.net.load_state_dict(global_model.net.state_dict())

def client_update_delta(global_model, client_model, data_split,
        num_features, max_norm, batch_size=16, epoch=1):
    """
    Trains client model for n epochs on the local data
    Sets delta = client_dict - global_dict as the parameters of the clients
    """
    x, y = transform_split(data_split, num_features)
    client_model.fit(x, y, batch_size=batch_size, epochs=epoch, verbose=0)

    client_dict = client_model.net.state_dict()
    #calculate delta
    for k in client_dict.keys():
        client_dict[k] -= global_model.net.state_dict()[k]
    
    total_norm = torch.norm(torch.stack([torch.norm(client_dict[k], 2) for k in client_dict.keys()]), 2)
    clip_coef = max_norm / (total_norm + 1e-6)
    clip_coef_clamped = torch.clamp(clip_coef, max=1.0)
    #clip delta to max_norm
    for k in client_dict.keys():
        client_dict[k] = client_dict[k].mul(clip_coef_clamped)

    #replace the updated delta of parameters into client models
    client_model.net.load_state_dict(client_dict)




def client_update(client_model, data_split, num_features,
                  batch_size=16, epoch=1):
    """
    Trains client model for n epochs on the local data
    """
    x, y = transform_split(data_split, num_features)
    client_model.fit(x, y, batch_size=batch_size, epochs=epoch, verbose=0)

def fedAvg(global_model, client_models, num_rounds, num_clients,
        num_selected, num_features, epochs):
    """
    Wrong. Needs work
    """
    ###### calculate the norm of a vector. Here the norm of the updates
    #First transform the collection into a list
    param = [global_dict[p] for p in global_dict.keys()]
    #For norm calculation make the list of parameters into a single vector by 
    #concatanation of all the vectors. 
    #For matrices, torch.norm(Mat, 2) returns l2 norm of the flattened matrix
    total_norm = torch.norm(torch.stack([torch.norm(p, 2) for p in param]), 2)

    for r in range(num_rounds):
        client_idx = np.random.permutation(num_clients)[:num_selected]
        for i in client_idx: #trains selected clients
            client_update(client_models[i], data_split[i], num_features, epochs)
        server_aggregate(global_model, client_models)

def data_split_rand(x, y, num_clients):
    """
    Randomly shuffle (x,y) and splits between num_clients
    """
    max_idx = (x.shape[0]//num_clients)*num_clients
    times = y[0]
    events = y[1]
    target = np.stack((times, events), axis=1)
    datatrain = np.concatenate((x, target), axis=1)
    np.random.shuffle(datatrain)
    data_split = np.split(datatrain[:max_idx], num_clients)
    return data_split

def transform_split(data_split, num_features):
    """
    Takes the randomly split data per clinets, separates x and y for
    that client and castes to correct types
    """
    x = data_split[:, :num_features].astype("float32") #split x_train                   
    y = data_split[:, -2:] #split y_train                                       
    y = np.transpose(y)   
    y0 = y[0].astype('int64') #times
    y1 = y[1].astype('float32') #events
    y = (y0, y1)
    return x, y 

    
