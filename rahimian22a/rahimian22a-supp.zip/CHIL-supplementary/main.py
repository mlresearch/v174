import argparse
import numpy as np 
import os
import model

def parser():
    """Parser of DeepHit PyCox"""
    parser = argparse.ArgumentParser()
    parser.add_argument(
            '-a', 
            '--alpha', 
            type=np.float32, 
            default=0.2, 
            help='alpha*nll + (1-alpha)*rankloss(sigma)'
            )
    parser.add_argument(
            '-s', 
            '--sigma', 
            type=np.float32, 
            default=0.1, 
            help='rankloss(sigma)'
            )
    parser.add_argument(
            '-d', 
            '--dataset', 
            type=str, 
            default="metabric", 
            help='dataset to train and test the model'
            )
    parser.add_argument(
            '-m', 
            '--model', 
            type=str, 
            default="deephit", 
            help='deephit/coxtime/coxcc/coxph'
            )
    parser.add_argument(
            '-f', 
            '--federated', 
            type=bool, 
            default=False, 
            help='whether or not use federation'
            )
    
    args = parser.parse_args()
    return args

def main():

    args = parser()
    model.run(args)

if __name__ == '__main__':
    main()
