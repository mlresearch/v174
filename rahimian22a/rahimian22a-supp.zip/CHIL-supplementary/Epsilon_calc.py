from __future__ import absolute_import
from __future__ import division

import numpy as np
from scipy.stats import norm
import pickle
from math import exp
from collections import Counter


import math

import numpy as np
from scipy import special
import six

l_max = 32 #lambda

# noise
SIGMA = 2.0

# Sampling prob. for SGD
SAMPLING_PROB= 5/10

SENSITIVITY = 0.1


# interval of integration; see integrate.quad from scipy

# DP parameter; we fix delta and compute the minimum epsilon
DELTA = 1e-3

# Total iterations : Federated rounds
T =  50

import scipy.integrate as integrate

def _log_add(logx, logy):
  """Add two numbers in the log space."""
  a, b = min(logx, logy), max(logx, logy)
  if a == -np.inf:  # adding 0
    return b
  # Use exp(a) + exp(b) = (exp(a - b) + 1) * exp(b)
  return math.log1p(math.exp(a - b)) + b  # log1p(x) = log(x + 1)

def _compute_log_a_int(q, sigma, alpha):
  """Compute log(A_alpha) for integer alpha. 0 < q < 1."""
  assert isinstance(alpha, six.integer_types)

  # Initialize with 0 in the log space.
  log_a = -np.inf

  for i in range(alpha + 1):
    log_coef_i = (
        math.log(special.binom(alpha, i)) + i * math.log(q) +
        (alpha - i) * math.log(1 - q+0.0001))

    s = log_coef_i + (i * i - i) / (2 * (sigma**2))
    log_a = _log_add(log_a, s)

  return float(log_a)


def _compute_log_a(q, sigma, alpha):
  """Compute log(A_alpha) for any positive finite alpha."""
  if float(alpha).is_integer():
    return _compute_log_a_int(q, sigma, int(alpha))
  else:
    raise Exception('Fractional alpha is not supported')

def compute_gauss_alpha(p_sigma, q, l, p_sens=1.0):
    '''
    e_1 = lambda x: norm.pdf(x,0,p_sens*p_sigma)* (norm.pdf(x,0,p_sens*p_sigma) / ((1-q)*norm.pdf(x,0,p_sens*p_sigma) +
        q*norm.pdf(x,p_sens,p_sens*p_sigma)))**l
    e_2 = lambda x: ((1-q)*norm.pdf(x,0,p_sens*p_sigma) + q*norm.pdf(x,p_sens,p_sens*p_sigma))*\
        ( ( (1-q)*norm.pdf(x,0,p_sens*p_sigma) + q*norm.pdf(x,p_sens,p_sens*p_sigma)) /
                norm.pdf(x,0,p_sens*p_sigma) ) **l

    E_1, _ = integrate.quad(e_1,-d, d)
    E_2, _ = integrate.quad(e_2,-d, d)
    return np.log( max([abs(E_1), abs(E_2)]))
    '''
    return _compute_log_a(q, p_sigma, l+1) 
 
## Alpha computation for different values of lambda from 1 to l_max

alpha_values = []

for l in range(1, l_max+1):
    alpha_val = compute_gauss_alpha(SIGMA, q=SAMPLING_PROB, l=l, p_sens=SENSITIVITY)
    print ("lambda = ", l, " alpha = ", alpha_val)
    alpha_values.append(alpha_val)

## Epsilon computation

eps_values = [ ]
cnt = Counter()
for i in range(T):
    epsilon_values = []
    for l in range(1,l_max+1):
        eps_t = ((i+1) * alpha_values[l-1] - np.log(DELTA)) / float(l)
        epsilon_values.append(eps_t)
    
    idx = np.argmin(epsilon_values)    
    cnt[idx]+=1
    eps_values.append(epsilon_values[idx])

print (cnt)

print ("Epsilon:", eps_values[T-1])
