import numpy as np 
import pandas as pd 
import random

from sklearn.preprocessing import StandardScaler
from sklearn_pandas import DataFrameMapper 
from pycox.datasets import metabric, gbsg, support

def data(dataset):
    """Returns normalized features
    """
    rnd = random.randint(0,10000)
    print(rnd)

    if dataset == "metabric":
        df_train = metabric.read_df()
        df_test = df_train.sample(frac=0.2, random_state=rnd)
        df_train = df_train.drop(df_test.index)
        cols_standardize = ['x0', 'x1', 'x2', 'x3', 'x8']
        cols_leave = ['x4', 'x5', 'x6', 'x7']

        standardize = [([col], StandardScaler()) for col in cols_standardize]
        leave = [(col, None) for col in cols_leave]

        x_mapper = DataFrameMapper(standardize + leave)
        x_train = x_mapper.fit_transform(df_train).astype('float32')
        x_test = x_mapper.transform(df_test).astype('float32')

    if dataset == "gbsg":
        df_train = gbsg.read_df()
        df_test = df_train.sample(frac=0.2, random_state=rnd)
        df_train = df_train.drop(df_test.index)
        cols_standardize = ['x3', 'x4', 'x5', 'x6']
        cols_leave = ['x0', 'x1', 'x2']

        standardize = [([col], StandardScaler()) for col in cols_standardize]
        leave = [(col, None) for col in cols_leave]

        x_mapper = DataFrameMapper(standardize + leave)
        x_train = x_mapper.fit_transform(df_train).astype('float32')
        x_test = x_mapper.transform(df_test).astype('float32')

    if dataset == "support":
        df_train = support.read_df()
        df_test = df_train.sample(frac=0.2, random_state=rnd)
        df_train = df_train.drop(df_test.index)
        cols_standardize = ['x0', 'x2',
                'x3', 'x6', 'x7', 'x8',
                'x9', 'x10', 'x11', 'x12',
                'x13']
        cols_leave = ['x1', 'x4', 'x5']

        standardize = [([col], StandardScaler()) for col in cols_standardize]
        leave = [(col, None) for col in cols_leave]

        x_mapper = DataFrameMapper(standardize + leave)
        x_train = x_mapper.fit_transform(df_train).astype('float32')
        x_test = x_mapper.transform(df_test).astype('float32')

    y_train = df_train[["duration", "event"]]
    y_test = df_test[["duration", "event"]]

    return x_train, y_train, x_test, y_test



