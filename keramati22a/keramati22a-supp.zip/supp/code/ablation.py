import numpy as np
import pickle
from core.giope import GIOPE
from sepsis_sim.sepsisSimDiabetes.State import State

from tqdm import tqdm
from sepsis_sim import data_generator as DGEN
from utils_ablation import *
from utils import *
import argparse

#np.random.seed(2)

class runner():
    def __init__(self, args):
        # initialzie config dicts
        self.config = {'policy_dir' : 'data/sepsis_policies.pkl',\
                        'tx_tr_dir' : 'data/tx_tr.pkl',\
                        'test_ratio' : 0.2,\
                        'function_max' : 1.0,\
                        'c':1.0,\
                        'C':5.0,\
                        'alpha':0.0,\
                        'max_depth':100,\
                        'min_sample':50,\
                        'test_itr':15}

        self.dgen_config = {'max_horizon': args.horizon,\
                            'p_diabetes': 0.2,\
                            'p_groups': [0.15, 0.4, 0.15, 0.3],\
                            'discount' : 0.99,\
                            'num_iters': 30000,\
                            'nS':1441,\
                            'nA': 8}

        self.model_types = ['sample', 'upper_bound', 'upper_bound_reg_01', 'upper_bound_reg_03', 'upper_bound_reg_04']

        self.args = args
        self.behaviour_policy, self.eval_policy = pickle.load(open(self.config['policy_dir'], 'rb'))
        self.tx, self.tr = pickle.load(open(self.config['tx_tr_dir'], 'rb'))

        self.results=dict()
        for model_type in self.model_types:
            self.results[model_type] = dict()

    def generate_data(self, test=False):
        '''generate data'''
        if test:
            num_iters = int(self.dgen_config['num_iters'] * self.config['test_ratio'])
        else:
            num_iters = int(self.dgen_config['num_iters'])

        dgen = DGEN.data_generator((self.tx, self.tr), self.behaviour_policy, self.dgen_config)
        b_traj, b_rets = dgen.simulate(num_iters, use_tqdm=False)
        _, _, _, _, cum = eval_wis(b_traj,\
                               b_policy=self.behaviour_policy, e_policy=self.eval_policy,\
                               discount=self.dgen_config['discount'], bootstrap=True, n_bootstrap=2)
        # reformat
        s0 = np.zeros((7, b_traj.shape[0]))
        s0_idx = np.zeros(b_traj.shape[0])
        g = b_traj[:, 0, 5]
        rets = b_rets[:]
        rho = cum[:]
        for i in range(b_traj.shape[0]):
            s0[:, i] = State(state_idx = b_traj[i, 0, 2], idx_type='full').get_state_vector()
            s0_idx[i] = b_traj[i, 0, 2]

        return s0_idx, s0.T, rho, rets

    def generate_model(self, model_type):
        '''return model'''
        # regularization function
        def reg(t, sigma, alpha=self.config['alpha']): 
            return np.maximum(0.0, alpha - (np.abs(t) - self.config['c'] * sigma))
        # return the model class
        if model_type == 'sample':
            return GIOPE(max_depth=self.config['max_depth'],\
                    min_sample=self.config['min_sample'], compute_bootstrap=True,\
                    variance_type='sample', function_max=self.config['function_max'],\
                    cross_fit=False, wis=False)

        elif model_type == 'upper_bound':
            return GIOPE(max_depth=self.config['max_depth'],\
                min_sample=self.config['min_sample'], compute_bootstrap=True,\
                variance_type='upper_bound', function_max=self.config['function_max'],\
                cross_fit=True, wis=False, regularizer=None)

        elif model_type == 'upper_bound_reg_01':
            c = np.sqrt((1.0-0.1)/0.1)
            def reg(t, sigma, alpha=self.config['alpha']):
                return np.maximum(0.0, alpha - (np.abs(t) - c * sigma))

            return GIOPE(regularizer=reg, max_depth=self.config['max_depth'],\
                 min_sample=self.config['min_sample'], compute_bootstrap=True,\
                 variance_type='upper_bound', function_max=self.config['function_max'],\
                 cross_fit=True,  wis=True)

        elif model_type == 'upper_bound_reg_04':
            c = np.sqrt((1.0-0.4)/0.4)
            def reg(t, sigma, alpha=self.config['alpha']):
                return np.maximum(0.0, alpha - (np.abs(t) - c * sigma))

            return GIOPE(regularizer=reg, max_depth=self.config['max_depth'],\
                 min_sample=self.config['min_sample'], compute_bootstrap=True,\
                 variance_type='upper_bound', function_max=self.config['function_max'],\
                 cross_fit=True,  wis=True)

        else:
            raise Exception("model type :{} not recognized".format(model_type))



    def evaluate_model(self, model, X_test, idx_test):
        '''run evaluatio on model'''
        n = idx_test.shape[0] # number of samples

        test_pred = np.zeros((n, 5)) #prediction
        test_true = np.zeros(n) # ground truth
        for i in tqdm(range(n)):
            init_idx = idx_test[i]
            predicted_value, predicted_info = model.predict(np.expand_dims(X_test[i, :], 0), info=True)
            dgen = DGEN.data_generator((self.tx, self.tr), self.behaviour_policy,\
                                        self.dgen_config, pre_identified_groups=False)
            _, rets_b = dgen.simulate(self.config['test_itr'], use_tqdm=False, init_state=init_idx)
            
            dgen = DGEN.data_generator((self.tx, self.tr), self.eval_policy,\
                                        self.dgen_config, pre_identified_groups=False)
            _, rets_e = dgen.simulate(self.config['test_itr'], use_tqdm=False, init_state=init_idx)
            test_pred[i, 0], (test_pred[i, 1], test_pred[i, 2]) = predicted_value[0], predicted_info[0]['CI']
            test_true[i] = np.mean(rets_e) - np.mean(rets_b)
        
        return test_true, test_pred

    def run(self):
        for ite in range(self.args.n_trial):
            # data genration
            _, X, w, y = self.generate_data()
            idx_test, X_test, _, _ = self.generate_data(test=True)
            # run different models
            for model_type in self.model_types:
                print(model_type)
                print('[*] Trial :{} out of {}, Model : {}, Horizon : {}, Model Fit'\
                    .format(ite, self.args.n_trial, model_type, self.args.horizon))
                model = self.generate_model(model_type) # generate model
                model.fit(X, y, w)  # fit model
                print('[*] Trial :{} out of {}, Model : {}, Horizon : {}, Model Evaluation'\
                    .format(ite, self.args.n_trial, model_type, self.args.horizon))
                true, pred = self.evaluate_model(model, X_test, idx_test) # evaluate model
                print('n_groups', np.unique(pred).shape[0])
                self.results[model_type][ite] = {'true': true, 'pred': pred}
                # save
                with open(self.args.save_dir + '_%d'%self.args.horizon + '.pkl', 'wb') as f:
                    pickle.dump(self.results, f)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Ablation Study')
    parser.add_argument('--horizon', type=int, default=5, help='Horizon of the study')
    parser.add_argument('--n_trial', default=20, help='number of trials')
    parser.add_argument('--function_max', default=1.0, help='Test data')
    parser.add_argument('--save_dir', default='results/ablation', help='Test data')
    args = parser.parse_args()
    
    exp = runner(args)
    exp.run()
