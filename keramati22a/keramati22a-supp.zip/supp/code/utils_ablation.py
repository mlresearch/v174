import numpy as np
from sepsis_sim import data_generator as DGEN

def retrieve_groups(predicted_value, Xeval):
    ''' to find the group distribution'''
    leaf_node_value = np.unique(predicted_value)
    group_assignment = np.zeros(predicted_value.shape[0])
    n_groups = leaf_node_value.shape[0]

    for i in range(n_groups):
        idx = predicted_value == leaf_node_value[i]
        group_assignment[idx] = i
        
    sizes = [3, 3, 2, 5, 2]
    dict_groups = {}
    for i in range(n_groups):
        idx = group_assignment == i
        s0_group = Xeval.T[:, idx]
        #print("### Group = {} has the following distribution:".format(i+1))
        dict_groups[i] = {}
        for s in range(4):
            all_possible = np.unique(s0_group[s, :])
            count = s0_group[s, :].shape[0]
            perc = np.zeros(sizes[s])
            for idx, poss in enumerate(all_possible):
                perc[int(poss)] = np.sum(s0_group[s, :] == poss)/count
            #print("\tfeature {} : {}".format(s, perc))
            dict_groups[i][s] = perc
    print("Number of groups : {}".format(n_groups))
    return dict_groups, n_groups, group_assignment

def evaluate_policies_in_groups(tx, tr, eval_policy, behaviour_policy, n_groups, dict_groups, config, use_tqdm=False):
    bp = np.zeros(n_groups)
    for i in range(n_groups):
        config['dict_groups'] = dict_groups[i]
        dgen = DGEN.data_generator((tx, tr), behaviour_policy, config, pre_identified_groups=True)
        _, rets = dgen.simulate(config['num_iters'], use_tqdm=use_tqdm)
        bp[i] = np.mean(rets)

    ep = np.zeros(n_groups)
    for i in range(n_groups):
        config['dict_groups'] = dict_groups[i]
        dgen = DGEN.data_generator((tx, tr), eval_policy, config, pre_identified_groups=True)
        _, rets = dgen.simulate(config['num_iters'], use_tqdm=False)
        ep[i] = np.mean(rets)

    return ep, bp