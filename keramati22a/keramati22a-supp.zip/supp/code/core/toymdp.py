import numpy as np

class ToyMDP():
    def __init__(self, H=1, 
                      config={'x_max' : 1, 'x_min' : 0,\
                      'alpha' : 0.2, 'goal' : 0.5}):
        '''toy mdp class
        Parameters
        ----------
        H : int
            horizon
        config: dict
            x_max : float
                maximum x
            x_min : float
                minimum x
            goal : float
                position of maximum reward
            alpha : float
                slope of movement given an action {-1, 0, 1}
        '''
        self.config = config
        self.actions = [-1, 0, 1]
        self.x = None
        self.t = None
        self.horizon = H
        self.epsilon = 0.05 # variance of noise
    def reset(self, x0=None):
        # reset
        if x0 == None:
            self.x = np.random.uniform(self.config['x_min'], self.config['x_max'])
        else:
            self.x = x0
        self.t = 0
        self.terminal = False
        
        return self.x
    
    def step(self, A):
        assert A in self.actions
        if self.terminal:
            return self.x, 0, self.terminal 
        
        self.t += 1
        if A == -1:
            self.x -= self.config['alpha'] + np.random.randn() * self.epsilon
        if A == 1:
            self.x += self.config['alpha'] + np.random.randn() * self.epsilon
        self.x = np.clip(self.x, self.config['x_min'], self.config['x_max'])
        
        if self.t == self.horizon:
            R = 1 - np.abs(self.x - self.config['goal'])
            self.terminal = True
        else:
            R = 1 - np.abs(self.x - self.config['goal'])
            self.terminal = False
        return self.x, R, self.terminal