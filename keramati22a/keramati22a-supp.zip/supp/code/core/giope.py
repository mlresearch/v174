import numpy as np

class GIOPE():
    def __init__(self, max_depth=10, 
                       min_sample=100, 
                       variance_type='upper_bound',\
                       compute_bootstrap=False, 
                       C=0, 
                       function_max=None, 
                       wis=False, 
                       cross_fit=True,
                       regularizer=None):
        '''GIOPE
        Group Identification in Off Policy Policy Evaluation
        code adopted from https://towardsdatascience.com/decision-tree-from-scratch-in-python-46e99dfea775
        
        Parameters
        ----------
        max_depth : int
            maximum tree depth, split stops if reaches that value
        min_sample : int
            minimum number of sample in each node, if resulting node has
            less samples than min_sample, node will not be splitted further
        variance_type : str
            how to compute variance
            upper_bound -- computes upper bound with sample max
            sample -- computes sample variance within the leaf
        compute_bootstrap : bool
            if compute bootstrap CI for the leaf node value
        C : float
            regularization constant
        function_max : float
            maximum of the function
        wis : bool
            if use Weighted importance sampling
        cross_fit : bool
            if use cross fitting with 50-50 split
        regulaizer : func
            a function to be used in regularization, 
            reg_value = regulaizer(y, w)
        '''
        self.max_depth = max_depth
        self.min_sample = min_sample
        self.compute_bootstrap = compute_bootstrap
        self.variance_type = variance_type
        self.C = C
        self.function_max = function_max
        self.wis = wis
        self.cross_fit = cross_fit
        self.regularizer = regularizer
        self.cross_fit_ratio = 0.5 # 50-50 corss fitting
        self.n_bootstrap = 1000

    def fit(self, X, y, w, features=None):
        ''' fit decision tree
        
        Parameters
        ----------
        X : float np.ndarray [n_sample, n_feature]
            numpy array features
        y : float np.array [n_sample]
            reutrn value for each sample
        w : float np.array [_nsample]
            importance weight for each sample (IS estimator)
        features : list
            list of str of name of each feature, default none
        '''
        assert X.shape[0] == y.shape[0], 'features and returns have to have same number of samples'
        assert X.shape[0] == w.shape[0], 'features and weights have to have same number of samples'
        assert len(X.shape) == 2, 'feature has to be 2D, got {}D'.format(len(X.shape))

        self.n_features = X.shape[1]
        self.n_sample = X.shape[0]
        
        # compute sample function max, if not specified
        if self.function_max is None:
            self.function_max = np.max(np.abs(y))

        # corss fitting
        if self.cross_fit:
            fit_idx = self._get_crossfit_index()
            self.tree_ = self._grow_tree(X[fit_idx, :], y[fit_idx], w[fit_idx], depth=0) 
            self._evaluate_nodes(self.tree_, X[~fit_idx, :], y[~fit_idx], w[~fit_idx])
        else:
            self.tree_ = self._grow_tree(X, y, w, depth=0) 

        # set feature names
        if features is None:
            self.features = ['X%d'%i for i in range(self.n_features)]
        else:
            self.features = features
    
    def _get_crossfit_index(self):
        '''get cross fit index,
        Return
        ------
        fit_idx : [bool]
            self.n_sample size of boolean indeax
            True : sample will be use in fitting
            False: sample will be used in evaluating
        '''
        choice = np.random.choice(np.arange(self.n_sample), int(self.n_sample * self.cross_fit_ratio), replace=False)
        fit_idx = np.zeros(self.n_sample).astype(bool)
        fit_idx[choice] = True
        return fit_idx

    def _grow_tree(self, X, y, w, depth=0):
        '''building the decision tree by recursively splitting the tree
        
        Parameters
        ----------
        X : float np.ndarray [n_sample, n_feature]
            numpy array features
        y : float np.array [n_sample]
            reutrn value for each sample
        w : float np.array [_nsample]
            importance weight for each sample (IS estimator)
        depth : int
            depth of the tree split (node)

        Return
        ------
        node : Node()
            decision node (with split criteria or lackthere of)
        '''
        predicted_value = self._compute_treatment_effect(y, w)
        variance = self._compute_variance(y, w)
        ess = self._compute_ess(w)
        CI05, CI95 = None, None
        if self.compute_bootstrap:
            CI05, CI95 = self._compute_bootstrap(y, w, B=self.n_bootstrap)

        loss_value = self._compute_loss(y, w)
       
        node = Node(
            loss_value = loss_value,
            num_sample =X.shape[0],
            w = w,
            predicted_value=predicted_value, 
            variance=variance,
            ess=ess,
            depth=depth,
            CI = (CI05, CI95),
        )

        # recursive split until stopping criteria
        if self._if_split(node):
            feature_idx, feature_threshold = self._best_split(X, y, w)
            if feature_idx is not None:
                indices_left = X[:, feature_idx] < feature_threshold
                X_left, y_left, w_left = X[indices_left, :], y[indices_left], w[indices_left]
                X_right, y_right, w_right = X[~indices_left, :], y[~indices_left], w[~indices_left]
                
                node.feature_index = feature_idx
                node.feature_threshold = feature_threshold
                node.left = self._grow_tree(X_left, y_left, w_left, depth + 1)
                node.right = self._grow_tree(X_right, y_right, w_right, depth + 1)

        return node

    def _compute_treatment_effect(self, y, w):
        '''compute the treatment effect
        Parameters
        ----------
        y : float np.array [n_sample]
            reutrn value for each sample
        w : float np.array [_nsample]
            importance weight for each sample (IS estimator)
        Return
        ------
        treatment_effect : float
            computed treatment effect
        '''
        if self.wis:
            return np.sum(w*y)/np.sum(w) - np.mean(y)
        else:
            return np.mean((w-1.0) * y)
    
    def _compute_variance(self, y,  w):
        '''compute the treatment effect
            Parameters
            ----------
            y : float np.array [n_sample]
                reutrn value for each sample
            w : float np.array [_nsample]
                importance weight for each sample (IS estimator)
            Return
            ------
            variance : float
                if self.variance_type == upper_bound
                    computed variance upper bound
                    sample max (y) * (1/ess - 1/n)
                else:
                    computew sample variance within the leaf
        '''
        if self.variance_type == 'upper_bound':
            ESS = self._compute_ess(w)
            N = y.shape[0]
            return self.function_max**2 * (1.0/ESS - 1.0/N)
        elif self.variance_type == 'sample':
            t = self._compute_treatment_effect(y, w)
            return np.mean(((w-1) * y - t)**2)
        else:
            raise Exception("variance type ({}) not recognized".format(self.variance_type))
    def _compute_regularization(self, y, w):
        '''compute the regularization values
        
        Parameters
        ----------
            y : float np.array [n_sample]
                reutrn value for each sample
            w : float np.array [_nsample]
                importance weight for each sample (IS estimator)
        Return
        ------
        regularization loss, without constant multiplication 
        '''
        if self.regularizer is not None:
            t = self._compute_treatment_effect(y, w)
            sigma = np.sqrt(self._compute_variance(y, w))
            return self.regularizer(t, sigma)
        else:
            return 0

    def _compute_loss(self, y, w):
        '''compute the loss
        loss = mse + var
        mse = -mean(treatment_effect**2)
        var = 2*mean(var(treatment_effect))

        Parameters
        ----------
            y : float np.array [n_sample]
                reutrn value for each sample
            w : float np.array [_nsample]
                importance weight for each sample (IS estimator)
        Return
        ------
        loss : float
            loss value
        '''
        t = self._compute_treatment_effect(y, w)
        v = self._compute_variance(y, w)
        loss = -t**2 + 2*v + self.C * self._compute_regularization(y, w)

        return loss

    def _compute_split_loss(self, y, w, i):
        '''compute the loss if split on i
        Parameters
        ----------
        i : int
            split point
        Return
        ------
        loss : float
        '''
        m = y.shape[0]

        loss_left = self._compute_loss(y[:i], w[:i])
        loss_right = self._compute_loss(y[i:], w[i:])

        return (i * loss_left + (m-i) * loss_right)/float(m)

    def _best_split(self, X, y, w):
        '''computes the best splitting point, loops over all features
        and all adjcent feature values, consideres the midpoint and 
        compute the loss value, and pick the minimum. 
        New loss should be smaller than old one.
        
        Parameters
        ----------
        X, y, w : faetures, returns and weights

        Returns
        -------
        feature_index : int
            index of the splitting feature
        feature_threshold : float
            thershold of the splitting feature
        '''
        # need at least two sample to split (only triggers if min_sample is not specified)
        m = y.shape[0]
        if m <= 2:
            return None, None
        
        feature_index, feature_threshold = None, None
        # current loss value: in parent case, no variance term (undefined)
        best_loss_value = self._compute_loss(y, w)

        # Loop over all features
        for idx in range(self.n_features):
            # sort data along the selected feature
            sorted_idx = np.argsort(X[:, idx])
            thresholds, rets, weights = X[sorted_idx, idx], y[sorted_idx], w[sorted_idx]

            split_points = np.arange(self.min_sample, m-self.min_sample)

            for i in split_points: #possible split points
                #RK : to speed up, saple points to split
                # avoid splitting on the same value
                if thresholds[i] == thresholds[i - 1]:
                    continue
                    
                loss_value = self._compute_split_loss(rets, weights, i) 
                if loss_value < best_loss_value:
                    best_loss_value = loss_value
                    feature_index = idx
                    feature_threshold = (thresholds[i] + thresholds[i - 1]) / 2  # midpoint
        
        return feature_index, feature_threshold

    def _compute_ess(self, w):
        # computes the effective sample size
        return np.sum(w)**2/np.sum(w**2)

    def _compute_bootstrap(self, y, w, B=1000):
        #compute 95% interval bootstrap
        results = np.zeros(B)
        n = y.shape[0]
        for idx in range(B):
            b_idx = np.random.choice(np.arange(n), replace=True, size=n)
            if self.wis:
                t = np.sum(w[b_idx] * y[b_idx])/np.sum(w[b_idx]) - np.mean(y[b_idx])
            else:
                t = (w[b_idx] - 1.0) * y[b_idx]
            results[idx] = np.mean(t)
        return np.quantile(results, 0.05), np.quantile(results, 0.95)

    def _if_split(self, node):
        '''if node satisfies splitting criteria'''
        if node.depth >= self.max_depth:
            return False
        if node.num_sample <= self.min_sample:
            return False
        return True

    # predict
    def predict(self, X, info=False):
        '''make prediction for input
        Parameters
        ----------
        X : float np.ndarray [n_sample, n_feature]
            numpy array features
        info : bool
            if returns info
        Returns
        -------
        y : float [n_sample]
            prediction
        '''
        if info:
            # RK: Fix this
            return np.array([self._predict(inputs)[0] for inputs in X]), np.array([self._predict(inputs)[1] for inputs in X])
        else:
            return np.array([self._predict(inputs)[0] for inputs in X])
    
    def _predict(self, x):
        # predict for a single example
        node = self.tree_
        rule = ""
        depth = 0
        while node.left:
            if x[node.feature_index] < node.feature_threshold:
                node = node.left
                rule += "{} {} < {:.3f} \n".format(' '.ljust(depth*2), self.features[node.feature_index],  node.feature_threshold)
            else:
                node = node.right
                rule += "{} {} > {:.3f} \n".format(' '.ljust(depth*2), self.features[node.feature_index],  node.feature_threshold)
            depth += 1
        info = {'variance' : node.variance,
                'CI': node.CI,'ESS':node.ess, 'rule':rule, 'n': node.num_sample, 'w':node.w}
        return node.predicted_value, info

    def _evaluate_nodes(self, node, X, y, w):
        '''evaluate nodes,
        Parameters
        ----------
        X, y, w : faetures, returns and weights
        node : Node
            the node to process
        
        Checks each time if cross fitting is True
        '''
        assert self.cross_fit, "_evaluate_nodes should only be called while cross fitting"

        if node.left:
            indices_left = X[:, node.feature_index] < node.feature_threshold
            X_left, y_left, w_left = X[indices_left, :], y[indices_left], w[indices_left]
            X_right, y_right, w_right = X[~indices_left, :], y[~indices_left], w[~indices_left]
            self._evaluate_nodes(node.left, X_left, y_left, w_left)
            self._evaluate_nodes(node.right, X_right, y_right, w_right)
        else:
            node.predicted_value = self._compute_treatment_effect(y, w)
            node.variance = self._compute_variance(y, w)
            node.ess = self._compute_ess(w)
            CI05, CI95 = None, None
            if self.compute_bootstrap:
                CI05, CI95 = self._compute_bootstrap(y, w, B=1000)
            node.CI = (CI05, CI95)
        return

class Node():
    def __init__(self, loss_value, num_sample, predicted_value, depth, variance, CI, ess, w):
        '''Node class
        Impelments node of the decision tree

        Parameters
        ----------
        loss_value : float
            loss value of the node
        num_sample : float
            number of samples in the node
        predicted_value : float
            prediction of the tree (loss_value is computed based on predicted_value)
        variance : float
            varaince either upper bound or sample based
        depth : int
            depth of the node in the teee
        ess : float
            effective sample size

        Attributes
        ----------
        feature_index : int
            which feature to split on
        feature_threshold : float
            threshold value to split on feature_index
        left, right : Node()
            left, right node after split
        '''
        self.loss_value = loss_value
        self.num_sample = num_sample
        self.predicted_value = predicted_value
        self.depth = depth
        self.variance = variance
        self.CI = CI
        self.w = w
        self.ess = ess
        self.feature_index = 0
        self.feature_threshold = 0
        self.left = None
        self.right = None

