import numpy as np
import mdptoolboxSrc.mdp as mdptools

def policyIteration(tx, tr, config):
    """Calculate the optimal policy for the marginal tx_mat and r_mat,
    using policy iteration from pymdptoolbox

    Note that this function marginalizes over any mixture components if
    they exist.

    Parameters
    ----------
    tx : float [n_actions, n_states, n_states]
        transition matrix
    tr : float [n_actions, n_states, n_states]
        reward matric
    config :
        - discount : float
            discount factor

    Returns
    -------
    pi : np.array, float [n_states, n_action]
        Determninistic optimal policy 
    """

    # Run Policy Iteration
    pi = mdptools.PolicyIteration(
        tx, tr, discount=config['discount'], skip_check=True,
        policy0=None, eval_type=1, max_iter=3000)
    pi.setSilent()
    pi.run()

    # Convert this (deterministic) policy pi into a matrix format 
    pol_opt = np.zeros((config['nS']+1, config['nA']))
    pol_opt[np.arange(len(pi.policy)), pi.policy] = 1

    return pol_opt

def calc_reward(trajectories, discount):
        """calc_reward
        calculates the discounted return

        Parameters
        ----------
        trajectories : np.array [num_iters, max_horizon, 5]
            output of process_data
        discout : float
            discount factor
        
        Returns
        -------
        discounted_reward : float [num_iters]
            discounted return for each trajectoru
        """
        # Column 0 is a time index, column 4 is the reward
        discounted_reward = (discount**trajectories[..., 0] * trajectories[..., 4])
        return discounted_reward.sum(axis=-1)  # Take the last axis

def eval_wis(traj, b_policy, e_policy, discount, bootstrap=False,\
             n_bootstrap=500, alpha=0.05, clip=False, clip_value=5):
    """eval_wis: adopted from David's paper
    Weighted Importance Sampling for Off Policy Evaluation

    Parameters
    ----------
    traj : [n_traj, H, 5]
        trajectories
    b_policy : [n_states, n_actions]
        behaviour policy
    e_policy : [n_states, n_actions]
        evaluation policy
    bootstrap : bool
        if perform bootstrapping
    n_bootstrap : int
        number of bootstraps
    alpha : float
        confidence interval
    clip : bool
        wheter to clip the weights

    Return
    ------
    wis : float
        Weighted importance sampling restimates of evaluation policie's return
    """
    # Check dimensions
    assert b_policy.ndim == 2
    assert e_policy.ndim == 2
    assert traj.ndim == 3

    # Precompute the discounted rewards and importance weights
    returns = calc_reward(traj, discount).squeeze()  # 1D array
    assert returns.ndim == 1

    actions = traj[..., 1].astype(int)
    states = traj[..., 2].astype(int)

    # probabilities
    p_e = e_policy[actions, states]
    p_b = b_policy[actions, states]

    # Deal with variable length sequences by setting ratio to 1
    terminated_idx = actions == -1
    p_b[terminated_idx] = 1
    p_e[terminated_idx] = 1

    assert np.all(p_b > 0), "Some actions had zero prob under behaviour policy, WIS fails"
    
    cum_ir = (p_e / p_b).prod(axis=1)
    if clip:
        cum_ir = np.clip(cum_ir, 0, clip_value)
    wis_idx = (cum_ir > 0)

    if wis_idx.sum() == 0:
        raise Exception("Found zero matching WIS samples, continuing")
    if bootstrap:
        assert n_bootstrap is not None, "Please specify n_bootstrap"
        # Get indices, because we need to sample from cum_ir and rewards
        idx = np.random.choice(
                np.arange(returns.shape[0]),
                size=(n_bootstrap, returns.shape[0]),
                replace=True)

        # Keepdims so that we can broadcast
        wis_bs_samps = (cum_ir[idx] /
                cum_ir[idx].sum(axis=1, keepdims=True)) * returns[idx]

        # Return WIS, one per row
        wis_est = wis_bs_samps.sum(axis=1)
        ordered = np.sort(wis_est)
        upper = np.quantile(ordered, 1-alpha/2)
        lower = np.quantile(ordered, alpha/2)
        return wis_est, np.mean(wis_est), lower, upper, cum_ir
    else:
        wis = (cum_ir) * returns
        if np.any(np.isnan(wis)):
            import pdb
            pdb.set_trace()
        wis_est = wis.sum()/cum_ir.sum()
        return wis_est