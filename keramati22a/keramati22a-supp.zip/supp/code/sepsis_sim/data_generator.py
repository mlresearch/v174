import numpy as np, random
from .sepsisSimDiabetes.MDP import MDP
from .sepsisSimDiabetes.State import State
from .sepsisSimDiabetes.Action import Action
from tqdm import tqdm
from .matrix_mdp import matrix_mdp

class data_generator(object):
    def __init__(self, transitions, policy, config, pre_identified_groups=False):
        
        """__init__
        wrapper around matrix_mdp to simulate trajectories from MDP
        
        Parameters
        ----------
        transitions: tuple (tx, tr)
            tx : np.array, float [n_actions, n_states, n_states]
                transition matrix
            tr : np.array, float [n_actions, n_states, n_states]
                reward matrix
        policy : np.array, float [n_actions, n_states]
            probability distribution over next state given action
        config : dictionary containing:
            max_horizon : int
                maximum number of timesteps in each simulation
            p_diabetes : float
                probability of a diabitic patinet
            p_healthy : float
                probability of a healthier patinet
            discount : float
                MDP's discount factor

        Methods
        -------
        simulate(num_iters)
            simulates num_iters trajectories and rewards by confounded_MDP
            returns trajectories and discounted returns
        process_data()
            process output of confounded MDP to trajectories and returns
        calc_reward()
            calculates discounted return
        """

        tx_mat, r_mat = transitions

        self.MDP = matrix_mdp(tx_mat, r_mat, policy, config, pre_identified_groups)
        self.max_num_steps = config['max_horizon']
        self.nS = config['nS']
        self.nA = config['nA']
        self.config = config

    def simulate(self, num_iters, use_tqdm=False, init_state=None):
        """simulates 
        Simulates num_iters trajectories and rewards by MDP
        
        Parameters
        ----------
        num_iters : int
            number of simulations
        use_tqdm : bool
            if use tqdm while running
        
        Returns
        -------
        trajectories : np.array [num_iters, max_horizon, 5]
            [num_iters, max_horizon, 0] : timestep
            [num_iters, max_horizon, 1] : action taken, -1 default
            [num_iters, max_horizon, 2] : state index
            [num_iters, max_horizon, 3] : next state index
            [num_iters, max_horizon, 4] : reward
        returns : np.array [num_iters]
            discounted returns by config['discount'] discount factor
        
        """

        # Set the default value of states / actions to negative -1,
        # corresponding to None
        iter_states = np.ones((num_iters, self.max_num_steps+1, 1), dtype=int)*(-1)
        iter_actions = np.ones((num_iters, self.max_num_steps, 1), dtype=int)*(-1)
        iter_rewards = np.zeros((num_iters, self.max_num_steps, 1))
        iter_groups = np.zeros((num_iters, 1))

        for itr in tqdm(range(num_iters), disable=not(use_tqdm)):
            # MDP will generate the diabetes index as well
            if init_state is None:
                state, group = self.MDP.reset()
            else:
                state, group = self.MDP.reset(init_state)

            iter_states[itr, 0, 0] = state #self.initial_state
            iter_groups[itr, 0] = group
            for step in range(self.max_num_steps):
                action = self.MDP.select_actions()
                # Take the action
                state, reward, terminal = self.MDP.step(action)

                iter_actions[itr, step, 0] = action
                iter_states[itr, step+1, 0] = state
                iter_rewards[itr, step, 0] = reward

                if terminal :
                    iter_rewards[itr, step, 0] = reward
                    break
        trajectories, returns = self.process_data(
                                iter_states[..., 0], iter_actions[..., 0], 
                                iter_rewards[..., 0], iter_groups, num_iters)

        return trajectories, returns

    
    def process_data(self, states, actions, rewards, groups, num_iters):
        """process_data 
        process states, actions and rewards into two arrays
        trajectories and rewards
        
        Parameters
        ----------
        states : np.array [num_iters, max_horizon]
            int, index of states
        actions : np.array [num_iters, max_horizon]
            int, index of actions            
        rewards : np.array [num_iters, max_horizon]
            float, index of actions    
        group : np.array [num_iters]
            int, group idx        
        num_iters : int
            number of iterations
        
        Returns
        -------
        trajectories : np.array [num_iters, max_horizon, 5]
            [num_iters, max_horizon, 0] : timestep
            [num_iters, max_horizon, 1] : action taken, -1 default
            [num_iters, max_horizon, 2] : state index
            [num_iters, max_horizon, 3] : next state index
            [num_iters, max_horizon, 4] : reward
            [num_iters, max_horizon, 5] : group
        disc_reward : np.array [num_iters]
            discounted returns by config['discount'] discount factor
        """

        disc_reward = np.zeros(num_iters)
        trajectories = np.zeros((num_iters, self.config['max_horizon'], 6))
        trajectories[:, :, 0] = np.arange(self.config['max_horizon'])  # Time Index
        trajectories[:, :, 1] = actions # actions
        trajectories[:, :, 2] = states[:, :-1]  # from_states
        trajectories[:, :, 3] = states[:, 1:]  # to_states
        trajectories[:, :, 4] = rewards # rewards
        trajectories[:, :, 5] = groups # rewards
        disc_reward = self.calc_reward(trajectories, discount=self.config['discount'])

        return trajectories, disc_reward

    def calc_reward(self, trajectories, discount):
        """calc_reward
        calculates the discounted return

        Parameters
        ----------
        trajectories : np.array [num_iters, max_horizon, 5]
            output of process_data
        discout : float
            discount factor
        
        Returns
        -------
        discounted_reward : float [num_iters]
            discounted return for each trajectoru
        """
        # Column 0 is a time index, column 4 is the reward
        discounted_reward = (discount**trajectories[..., 0] * trajectories[..., 4])
        return discounted_reward.sum(axis=-1)  # Take the last axis
    
    def calc_tx_tr(self, trajectories):
        """calc_tx_tr

        calculate, tx and tr matricies

        Parameters
        ----------
        trajectories : np.array [num_iters, max_horizon, 5]
            output of process_data
        
                Returns
        -------
        tx : float [n_action, n_states, n_states]
            transition matrix
        tr : float [n_action, n_states, n_states]
            reward matrix
        """
        tx = np.zeros((self.nA, self.nS+1, self.nS+1))
        tr = np.zeros((self.nA, self.nS+1, self.nS+1)) 
        for traj in range(trajectories.shape[0]):
            for t in range(trajectories.shape[1]):
                a = int(trajectories[traj, t, 1])
                if a != -1:
                    s = int(trajectories[traj, t, 2])
                    ns = int(trajectories[traj, t, 3])
                    r = trajectories[traj, t, 4]
                    tx[a, s, ns] += 1
                    if r != 0: #terminal state
                        tx[:, s, :] = 0 # transition probability to any othre state it's zero
                        tx[:, s, self.nS] = 1 # Transition to terminal
                    tr[:, :, ns] = r # this is specific to this env.

        tx = np.nan_to_num(tx / tx.sum(axis=-1, keepdims=True))
        tx[:,  self.nS,  self.nS] = 1
        tr[:,  self.nS,  self.nS] = 0

        return tx, tr