import numpy as np, random
from .sepsisSimDiabetes.MDP import MDP
from .sepsisSimDiabetes.State import State
from .sepsisSimDiabetes.Action import Action

class matrix_mdp(object):
    def __init__(self, tx_mat, r_mat, policy, config, pre_identified_groups = False):
        """__init__
        Implements an MDP with a transiton and reward matrix, such that the first step 
            policy can be different from the rest, and first step may be confounde.
        
        Parameters
        ----------
        tx_mat: np.array, float  [n_actions, n_states, n_states]
            Transition matrix of shape [n_actions, n_states, n_states]
        r_mat : np.array, float [n_actions, n_states, n_states]
            Reward matrix of shape [n_actions, n_states, n_states]
        policy : np.array, float [n_action, n_states]
            Probability distribution over next action given state 
            This policy is used from t=1 onward.
        config : dictionary containts the following
            max_horizon : int
                maximum number of timesteps in each simulation
            p_groups : [float]
                probablity of each group 
        pre_identified_groups : bool
            if group distribtuion is specified before hand

        Methods
        -------
        generate_random_state()
            generates a random state as initial state
            returns a State object
        reset()
            reset the MDP and return the initial state
        step()
            takes a step based on policy and returns 
            next state, reward, if terminal
        select_actions()
            select the next action
        """

        # size of the inputs
        assert tx_mat.ndim == 3, \
            "Transition matrix wrong dims ({} != 3)".format(tx_mat.ndim)
        assert r_mat.ndim == 3, \
            "Reward matrix wrong dims ({} != 3)".format(tx_mat.ndim)
        assert r_mat.shape == tx_mat.shape, \
            "Transition / Reward matricies not the same shape!"
        assert tx_mat.shape[-1] == tx_mat.shape[-2], \
            "Last two dims of Tx matrix should be equal to num of states"

        # Get the number of actions and states
        n_actions = tx_mat.shape[0]
        n_states = tx_mat.shape[1]

        self.max_horizon = config['max_horizon']
        self.p_groups = config['p_groups']
        self.p_diabetes = 0.2

        self.n_actions = n_actions
        self.n_states = n_states
        self.tx_mat = tx_mat
        self.r_mat = r_mat

        self.current_state = None
        
        self.policy = policy
        self.pre_identified_groups = False
        if pre_identified_groups:
            self.pre_identified_groups = True
            self.prob_hr = config['dict_groups'][0]
            self.prob_sysbp = config['dict_groups'][1]
            self.prob_oxyg = config['dict_groups'][2]
            self.prob_diabetes = config['dict_groups'][3]

    def generate_random_state(self):
        """generates a random initial state
        with pre defined prior.

        Returns
        -------
        State : fully specified State object
        """
        # Note that we will condition on diabetic idx if provided
        group = np.random.choice(np.arange(len(self.p_groups)), p=self.p_groups)
        p_diabetes = self.p_diabetes
        # RK : put vectors for each group
        prob_hr = [.25, .5, .25]
        prob_sysbp = [.25, .5, .25]
        prob_oxyg = [0.2, 0.8]
        prob_diabetes = [.05, .15, .6, .15, .05]   

        if group == 1:
            prob_diabetes = [0.9, .1, .0, .0, .0]   
            p_diabetes = 0.9           
            prob_sysbp = [1.0, .0, .0] 
        if group == 2:
            prob_oxyg = [0.8, 0.2]
        if group == 3:
            prob_diabetes = [.0, .0, .0, .1, .9] 
            prob_hr = [.0, .0, 1.0]
        if group == 4:
            prob_oxyg = [1.0, 0.0]
            prob_sysbp = [1.0, .0, 0.0]
        
        diabetic_idx = np.random.binomial(1, p_diabetes)
        # hr and sys_bp w.p. prob_vec
        hr_state = np.random.choice(np.arange(3), p=np.array(prob_hr))
        sysbp_state = np.random.choice(np.arange(3), p=np.array(prob_sysbp))
        # percoxyg w.p. per_vec
        percoxyg_state = np.random.choice(np.arange(2), p=np.array(prob_oxyg))

        glucose_state = np.random.choice(np.arange(5), \
                p=np.array(prob_diabetes))
        # if diabetic_idx == 0:
        #     glucose_state = np.random.choice(np.arange(5), \
        #         p=np.array([.05, .15, .6, .15, .05]))
        # else:
        #     glucose_state = np.random.choice(np.arange(5), \
        #         p=np.array([.01, .05, .15, .6, .19]))
        antibiotic_state = 0
        vaso_state = 0
        vent_state = 0

        state_categs = [hr_state, sysbp_state, percoxyg_state,
                glucose_state, antibiotic_state, vaso_state, vent_state]

        return State(state_categs=state_categs, diabetic_idx=diabetic_idx, group_idx=group)

    def generate_random_state_with_pre_groups(self):
        """generates a random initial state
        with pre defined prior.

        Returns
        -------
        State : fully specified State object
        """
        diabetic_idx = np.random.binomial(1, self.p_diabetes)
        # hr and sys_bp w.p. prob_vec
        hr_state = np.random.choice(np.arange(3), p=np.array(self.prob_hr))
        sysbp_state = np.random.choice(np.arange(3), p=np.array(self.prob_sysbp))
        # percoxyg w.p. per_vec
        percoxyg_state = np.random.choice(np.arange(2), p=np.array(self.prob_oxyg))

        glucose_state = np.random.choice(np.arange(5), \
                p=np.array(self.prob_diabetes))
        antibiotic_state = 0
        vaso_state = 0
        vent_state = 0

        state_categs = [hr_state, sysbp_state, percoxyg_state,
                glucose_state, antibiotic_state, vaso_state, vent_state]

        return State(state_categs=state_categs, diabetic_idx=diabetic_idx)

    def reset(self, init_state=None):
        """reset
        Reset the environment by 
            1. reseting the initial state
            2. setting self.time = 0
        Returns
        -------
        self.current_state : int
            index of the current (initial) state
        """
        if init_state is None:
            # Draw an initial state
            if not self.pre_identified_groups:
                init_state = self.generate_random_state()
                while init_state.check_absorbing_state():
                    init_state = self.generate_random_state()
            else:
                init_state = self.generate_random_state_with_pre_groups()
                while init_state.check_absorbing_state():
                    init_state = self.generate_random_state_with_pre_groups()
        else:   
            init_state = State(state_idx=init_state, idx_type='full')
            init_state.group = 0
        self.current_state = init_state.get_state_idx()
        self.time = 0

        return self.current_state, init_state.get_group()

    def step(self, action):
        """step
        Take a step with the given action

        Patameters
        ----------
        action : int
            index of the action
        
        Returns
        -------
        self.current_state : int
            index of the next state
        reward : float
            reward of (state, action, next state)
        is_term : bool
            if self.current_state is a terminal state
        """
        assert action in range(self.n_actions), "Invalid action!"
        assert self.time < self.max_horizon, "Out of time horizon!"
        is_term = False

        next_prob = self.tx_mat[action, self.current_state,
                :].squeeze()

        assert np.isclose(next_prob.sum(), 1), "Probs do not sum to 1!"
        next_state = np.random.choice(self.n_states, size=1, p=next_prob)[0]

        reward = self.r_mat[action, self.current_state, next_state]
        self.current_state = next_state

        # In this MDP, rewards are only received at the terminal state
        if reward != 0:
            is_term = True

        self.time += 1
        if self.time >= self.max_horizon:
            is_term = True

        return self.current_state, reward, is_term

    def select_actions(self):
        """select_actions

        Returns
        -------
        next_action : int
            index of the next action
        """
        next_prob = self.policy[:, self.current_state].squeeze()

        assert np.isclose(next_prob.sum(), 1), "Probs do not sum to 1!"

        next_action = np.random.choice(self.n_actions, size=1, p=next_prob)[0]

        return next_action