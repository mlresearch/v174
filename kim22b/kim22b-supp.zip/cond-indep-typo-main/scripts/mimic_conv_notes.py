# This script loads NOTEEVENTS.csv from MIMIC-III and extract CUIs with MetaMap.
# The results (ROW_ID, SUBJECT_ID, HADM_ID, CUI_SEQ) will be saved as a csv file
# and be further used in the data pre-processing pipeline.

import numpy as np
import pandas as pd
import re
import os
import pickle
import argparse
from tqdm import tqdm
from multiprocessing.pool import ThreadPool
import subprocess
import tempfile
import string
from collections import Counter

if __name__=="__main__":
    parser = argparse.ArgumentParser('MIMIC-III Preprocessing - 1. CUI extraction from clinical notes')
    parser.add_argument('--mimic_root', type=str, default='mimic3', help="Path to the root of MIMIC-III dataset")
    parser.add_argument('--discharge_only', dest='discharge_only', action='store_true')
    parser.add_argument('--no_discharge_only', dest='discharge_only', action='store_false')
    parser.set_defaults(discharge_only=True)
    parser.add_argument('--metamap_root', type=str, default='metamap', help="Path to the root of MetaMap")
    parser.add_argument('--pool', type=int, default=-1, help="The number of parallel process running MetaMap")
    parser.add_argument('--metamap_timeout', type=int, default=600, help="Timeout per MetaMap process (in seconds)")
    parser.add_argument('--output_dir', type=str, default='data/mimic_notes', help="Path to the output dir")
    args = parser.parse_args()

anon_pattern = re.compile('\[\*\*.*?\*\*\]')
type_pattern = re.compile('\[.*?\]')
valid_cui_types = {'[Sign or Symptom]', '[Disease or Syndrome]', '[Neoplastic Process]',
                   '[Therapeutic or Preventive Procedure]'}


def remove_anonymized(t):
    """ Remove anonymized terms (wrapped by [** and **]) """
    ret = ''
    start, end = 0, len(t)
    for m in anon_pattern.finditer(t):
        end = m.start()
        ret += t[start:end]
        start = m.end()
    end = len(t)
    ret += t[start:end]
    return ret

def sanitize_text(t):
    """ Case-by-case text sanitizing """
    l = t.split('\n')
    for s in l:
        if s.startswith('.....'):
            l.remove(s)
    return '\n'.join(l)

def clean_text(text):
    """ Text cleaning by Linyuan """
    sl = []
    for s in text.strip().split('\n'):
        # s = re.sub(r'\[\*\*.*?\*\*\]', ' ', s)
        if not re.search('[a-zA-Z]', s):
            s = ''
        else:
            s = re.sub(r'\?{3,}', ' ', s)
            s = re.sub(r'-{3,}', ' ', s)
            s = re.sub(r'(- ){3,}', ' ', s)
            s = re.sub(r'#{3,}', ' ', s)
            s = re.sub(r'\*{3,}', ' ', s)
            s = re.sub(r'~{3,}', ' ', s)
            s = re.sub(r'`{3,}', ' ', s)
            s = re.sub(r'_{3,}', ' ', s)
            s = re.sub(r'\.{2,}', '.', s)
            s = re.sub(r'{+', '(', s)
            s = re.sub(r'\}+', ')', s)
            s = re.sub(r'\'{2,}', '\'', s)
            s = re.sub(r'!{2,}', '!', s)
            s = re.sub(r'<{2,}', '<', s)
            s = re.sub(r'>{2,}', '>', s)
            s = re.sub(r'\+{5,}', '+++++', s)
            s = ' '.join(s.strip().split())
        if s.startswith("===") and s.endswith("==="):
            s = s.strip("=")
            s = re.sub(r'={3,}', ' ', s)
            s = ' '.join(s.strip().split())
            if sl and sl[-1]:
                sl.append("")
            sl.append(s)
            sl.append("")
        else:
            s = re.sub(r'={3,}', ' ', s)
            s = ' '.join(s.strip().split())
            # if sl and sl[-1] and s:
            if sl and sl[-1] and s and s[0] in string.ascii_letters: # condition to be appended changed
                sl[-1] += ' ' + s
            elif (sl and sl[-1]) or s:
                sl.append(s)
    # sl = [s for s in sl if s]
    # sl2 = []
    # for s in sl:
        # ct = Counter(s)
        # score = sum(ct[ch] for ch in string.ascii_letters + string.digits) + ct[' '] * 0.25
        # if score / len(s) >= 0.6:
            # sl2.append(s)
    # return '\n'.join(sl2)
    return '\n'.join(sl)

def parse_metamap_output(lines):
    """ Parse the output of MetaMap and outputs the list of CUIs found by MetaMap """
    cuis = []
    idx = 0
    while idx < len(lines):
        l = lines[idx]
        if l.startswith('Phrase:'):
            idx += 1
            if idx >= len(lines):
                break
            l = lines[idx]
            if l.startswith('Meta Mapping'):
                while True:
                    idx += 1
                    if idx >= len(lines):
                        break
                    l = lines[idx].strip()
                    if not l[:l.find(' ')].isdigit():
                        break
                    C_idx = l.find('C')
                    cui = l[C_idx:C_idx+8]
                    # cui_type = type_pattern.search(l).group(0)
                    # if cui_type in valid_cui_types:
                        # cuis.append(cui)
                    cuis.append(cui)
        idx += 1
    return cuis

def metamap_job(metamap_fpath, t, job_id, row_id, subject_id, hadm_id, timeout=60):
    """ Run MetaMap and get the output """
    # Create tempfiles to get input/output of MetaMap
    # tt = remove_anonymized(t)
    tt = sanitize_text(t)
    tt = clean_text(tt) + '\n'
    if len(tt) == 0:
        print('Wrong text (ROW_ID: %d)' % (row_id))
        return
    in_tempfpath = '/tmp/tmp' + next(tempfile._get_candidate_names())
    out_tempfpath = '/tmp/tmp' + next(tempfile._get_candidate_names())

    # Fetch a process
    cuis = []
    try:
        while True:
            with open(in_tempfpath, 'wb') as fd:
                fd.write(tt.encode('utf8'))
            mm_cmd = [metamap_fpath, '--prune', '17', '-I', in_tempfpath, out_tempfpath]
            mm_process = subprocess.Popen(mm_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            try:
                mm_ret = mm_process.wait(timeout=timeout)
            except subprocess.TimeoutExpired as e:
                # When timeout, just parse with the output made so far
                print('    Timeout MetaMap job(%d, ROW_ID: %d)' % (job_id, row_id))
                mm_process.kill()

            # Parse output
            with open(out_tempfpath, 'r') as fd:
                output_lines = fd.readlines()
            cuis = parse_metamap_output(output_lines)

            if not cuis and not output_lines:  # When no MetaMap output made, something is wrong with MetaMap
                print('    Retrying Metamap job(%d, ROW_ID: %d)' % (job_id, row_id))
            else:
                break
    except Exception as e:
        print('    Got error during metamap job(%d, ROW_ID: %d)' % (job_id, row_id))
        import traceback
        traceback.print_tb(e.__traceback__)

    # Clear up
    os.remove(in_tempfpath)
    os.remove(out_tempfpath)

    # print('  Metamap job done(%d - %d CUIs, %s -> %s)' % (job_id, len(cuis), in_tempfpath, out_tempfpath))
    print('  Metamap job done(%d, ROW_ID: %d - %d CUIs)' % (job_id, row_id, len(cuis)))
    return [cuis, (row_id, subject_id, hadm_id)]

def main():
    # Print settings
    print('Settings\n' + '\n'.join(["\t{0}: {1}".format(k,v) for k, v in vars(args).items()]))

    # Load notes CSV
    # notes_fpath = os.path.join(args.mimic_root, 'NOTEEVENTS_small3.csv')
    notes_fpath = os.path.join(args.mimic_root, 'csv/NOTEEVENTS.csv')
    print('Load notes: %s... ' % notes_fpath, end='', flush=True)
    df_note = pd.read_csv(notes_fpath, low_memory=False)
    if args.discharge_only:
        print('(Discharge summary only...) ', end='', flush=True)
        df_note = df_note[df_note['CATEGORY'] == "Discharge summary"]
    print('%d notes' % len(df_note))
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
    notes_out_fpath = os.path.join(args.output_dir, 'discharge_note.csv')
    print('Save discharge summary notes: %s...' % notes_out_fpath, end='', flush=True)
    df_note.to_csv(notes_out_fpath, index=False)
    print('done')

    # Pooling MetaMap jobs
    metamap_fpath = os.path.join(args.metamap_root, 'public_mm/bin/metamap')
    pool_size = args.pool
    if pool_size == -1:
        pool_size = os.cpu_count()
    print('Pooling MetaMap jobs (%d jobs -> %d subprocesses)' % (len(df_note), pool_size), flush=True)
    mm_threadpool = ThreadPool(pool_size)
    results = []
    for i, (row_id, row) in tqdm(enumerate(df_note.iterrows())):
        # print('Queue job %d (%s)' % (row.ROW_ID, row.CATEGORY))
        # out_fname = '%d-%d-%d' & (row.ROW_ID, row.SUBJECT_ID, row.HADM_ID)
        ret = mm_threadpool.apply_async(metamap_job, (metamap_fpath, row.TEXT, i, row.ROW_ID, row.SUBJECT_ID, row.HADM_ID, args.metamap_timeout))
        results.append(ret)
    mm_threadpool.close()
    mm_threadpool.join()
    results = [r.get() for r in results]
    print('MetaMap job done!')

    # Write output
    output_fpath = os.path.join(args.output_dir, 'note_cui.csv')
    print('Write output: %s... ' % output_fpath, flush=True)
    cuis, row_ids, subject_ids, hadm_ids = [], [], [], []
    for i, (cui, (row_id, subject_id, hadm_id)) in enumerate(tqdm(results)):
        cuis.append(' '.join(cui))
        row_ids.append(row_id)
        subject_ids.append(subject_id)
        hadm_ids.append(hadm_id)
    df_output = pd.DataFrame([row_ids, subject_ids, hadm_ids, cuis]).transpose()
    if not os.path.exists(args.output_dir):
        print('Make output dir: %s' % args.output_dir)
        os.makedirs(args.output_dir)
    df_output.columns = ["ROW_ID","SUBJECT_ID","HADM_ID","CUI_SEQ"]
    df_output.to_csv(output_fpath, index=False)
    print('done')


if __name__ == "__main__":
    main()
