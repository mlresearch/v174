#!/bin/bash
#export CUDA_VISIBLE_DEVICES=1

code_dir=`pwd`
base_dir=$(dirname "$code_dir")
exp_base="layer24"
dataset=mimic_synthetic

dict_file=$code_dir/data/lexicon/lexicon.json
mimic_csv_dir=$base_dir/mimic3_noteevents_split
data_dir=$code_dir/data/$dataset
output_dir=$base_dir/exp/cond_indep_typo/$exp_base

length_penalty=1.0
beam_sort_linear_ed="beam_sort_ed"
beam_final_score_normalize_ed="beam_final_score_normalize_ed"
edit_distance_weight=5.0

python run.py \
    --mimic_csv_dir=$mimic_csv_dir \
    --data_dir=$data_dir \
    --bert_dir=$base_dir/bert_models_large \
    --dict_file=$dict_file \
    --output_dir=$output_dir \
    --is_train \
    --dropout=0.1 \
    --decoder_layers=24 \
    --train_bert \
    --batch_size=128 \
    --num_gpus=2 \
    --num_beams=3 \
    --edit_distance_weight=$edit_distance_weight \
    --length_penalty=$length_penalty \
    --$beam_sort_linear_ed \
    --$beam_final_score_normalize_ed \
    --dict_matching \
    --training_step=200000 \
    --display_iter=25 \
    --eval_iter=2000 \
    --lr 0.0001 \
    #--init_ckpt=$output_dir/ckpt.pkl \
    #--init_step=100000
