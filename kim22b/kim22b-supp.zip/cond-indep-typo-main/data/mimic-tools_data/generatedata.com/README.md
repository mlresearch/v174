These lists have been randomly computed using the software available at http://benkeen.github.io/generatedata/

A demo version of this tool limited to 100 elements per list is available at http://generatedata.com/