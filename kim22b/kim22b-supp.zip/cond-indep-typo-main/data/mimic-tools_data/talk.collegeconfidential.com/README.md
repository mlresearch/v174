The list of colleges in the USA has been computed based on the information provided at
http://talk.collegeconfidential.com/alphabetic-list-colleges/