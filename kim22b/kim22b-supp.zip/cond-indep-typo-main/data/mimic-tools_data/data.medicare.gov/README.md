The list of US public hospitals has been created using the data provided
at https://data.medicare.gov/data/hospital-compare