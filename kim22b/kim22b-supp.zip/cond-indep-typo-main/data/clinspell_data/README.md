To compare with the lexicon of Fivez et al. please download `lexicon_en.json` file from https://github.com/clips/clinspell/tree/master/data and put under `data/clinspell_data`.
