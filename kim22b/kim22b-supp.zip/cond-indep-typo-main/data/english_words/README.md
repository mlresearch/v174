Please download `english.txt` from https://github.com/dwyl/english-words/ (the version of Dec. 14, 2020) and put under this directory.
