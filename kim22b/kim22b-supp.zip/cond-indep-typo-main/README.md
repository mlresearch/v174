# Conditional Independence Model

This repository implements typo correction method based on noisy channel model with conditional independence assumption.

## Acknowledgements

The model is based on the BART implementation of Hugging Face's [Transformers](https://huggingface.co/transformers/). The encoder part is initialized with [BlueBERT](https://github.com/ncbi-nlp/bluebert) (formerly NCBI-BERT). We thank Julien Tourille for the pseudonymization module of the MIMIC-III dataset ([this repository](https://github.com/jtourille/mimic-tools)). To build lexicon, we use [this english dictionary](https://github.com/dwyl/english-words). Damerau-Levenshtein distance is computed using [this implementation](https://github.com/robertgr991/fastDamerauLevenshtein).
