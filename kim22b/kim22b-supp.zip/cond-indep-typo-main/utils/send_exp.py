#!/usr/bin/env python
# -*- coding=utf-8 -*-

import os

def send_exp(output_dir):
    host = os.environ['send_exp_host']
    username = os.environ['send_exp_username']
    password = os.environ['send_exp_password']
    host_exp_dpath = os.environ['send_exp_dpath']
    command_str = f'sshpass -p "{password}" scp -r -o StrictHostKeyChecking=no {output_dir} {username}@{host}:{host_exp_dpath}'
    os.system(command_str)
