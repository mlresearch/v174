#!/usr/bin/python

import numpy as np


INF = 1e10

def damerau_levenshtein_distance(str1, str2):
    """ Returns Damerau-Levenshtein edit distance with the number of each
    operation needed. Note that it's very slow since written in pure Python. """

    len1, len2 = len(str1), len(str2)
    # print(f'{str1} - {len1}, {str2} - {len2}')

    # dist_mat[i, j] = ED(str1[:i], str[:j])
    # oper_mat[i, j] = (number of add, del, sub, tra from str1[:i], str2[:j])
    dist_mat = np.zeros((len1 + 1, len2 + 1), dtype=np.int32)
    oper_mat = np.zeros((len1 + 1, len2 + 1, 4), dtype=np.int32) # Add, Del, Sub, Tra
    dist_mat[0, :] = range(len2 + 1) # Init: add
    oper_mat[0, :, 0] = range(len2 + 1)
    dist_mat[:, 0] = range(len1 + 1) # Init: del
    oper_mat[:, 0, 1] = range(len1 + 1)

    str1, str2 = "@" + str1, "@" + str2

    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            # print(f'i={i}, j={j}')
            add_cand = dist_mat[i, j-1] + 1
            del_cand = dist_mat[i-1, j] + 1
            sub_cand = dist_mat[i-1, j-1] + (1 if str1[i] != str2[j] else 0)
            sub_oper = (0, 0, 1 if str1[i] != str2[j] else 0, 0)
            if (i > 1) and (j > 1) and (str1[i] == str2[j-1]) and (str1[i-1] == str2[j]):
                tra_cand = dist_mat[i-2, j-2] + 1
            else:
                tra_cand = INF

            if tra_cand <= min(add_cand, del_cand, sub_cand):
                dist_mat[i, j] = tra_cand
                oper_mat[i, j] = oper_mat[i-2, j-2] + (0, 0, 0, 1)
            elif sub_cand <= min(add_cand, del_cand):
                dist_mat[i, j] = sub_cand
                oper_mat[i, j] = oper_mat[i-1, j-1] + sub_oper
            elif del_cand <= add_cand:
                dist_mat[i, j] = del_cand
                oper_mat[i, j] = oper_mat[i-1, j] + (0, 1, 0, 0)
            else:
                dist_mat[i, j] = add_cand
                oper_mat[i, j] = oper_mat[i, j-1] + (1, 0, 0, 0)

    # print(dist_mat)

    return dist_mat[-1, -1], oper_mat[-1, -1].tolist()
