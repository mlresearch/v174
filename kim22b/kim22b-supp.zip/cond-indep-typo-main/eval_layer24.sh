#!/bin/bash
#export CUDA_VISIBLE_DEVICES=1

code_dir=`pwd`
base_dir=$(dirname "$code_dir")
exp_base="layer24_aws"
dataset=mimic_synthetic

dict_file=$code_dir/data/lexicon/lexicon.json
mimic_csv_dir=$base_dir/mimic3_noteevents_split
data_dir=$code_dir/data/$dataset
output_dir=$base_dir/exp/cond_indep_typo/$exp_base
edit_distance_extra_len=100
#edit_distance_extra_len=2
#edit_distance_extra_len=1

for num_beams in 3 10 30
do
    for config in 1 2 3
    do
        for ed_idx in 0 1 2 3
        do
            if [[ "$config" -eq "1" ]]
            then
                length_penalty=1.0
                beam_sort_linear_ed="beam_sort_linear_ed"
                beam_final_score_normalize_ed="beam_final_score_normalize_ed"
                ed_list=(0.3 1.0 2.0 5.0)
                edit_distance_weight=${ed_list[ed_idx]}
            fi
            if [[ "$config" -eq "2" ]]
            then
                length_penalty=1.0
                beam_sort_linear_ed="beam_sort_ed"
                beam_final_score_normalize_ed="beam_final_score_normalize_ed"
                ed_list=(2.0 5.0 10.0 20.0)
                edit_distance_weight=${ed_list[ed_idx]}
            fi
            if [[ "$config" -eq "3" ]]
            then
                length_penalty=0.0
                beam_sort_linear_ed="beam_sort_ed"
                beam_final_score_normalize_ed="beam_final_score_unnormalize_ed"
                ed_list=(2.0 5.0 10.0 20.0)
                edit_distance_weight=${ed_list[ed_idx]}
            fi

            # Evaluate on the MIMIC real dataset
            python run.py \
                --is_eval \
                --data_dir=$code_dir/data/mimic_clinspell \
                --test_file=test.tsv \
                --dict_file=$dict_file \
                --bert_dir=$base_dir/bert_models_large \
                --output_dir=$output_dir \
                --decoder_layers=24 \
                --batch_size=32 \
                --num_gpus=2 \
                --num_beams=$num_beams \
                --edit_distance_weight=$edit_distance_weight \
                --edit_distance_extra_len=$edit_distance_extra_len \
                --length_penalty=$length_penalty \
                --$beam_sort_linear_ed \
                --$beam_final_score_normalize_ed \
                --dict_matching \

            # Evaulate on the val set of synthetic typo dataset
            python run.py \
                --is_eval \
                --data_dir=$data_dir \
                --test_file=val.tsv \
                --dict_file=$dict_file \
                --bert_dir=$base_dir/bert_models_large \
                --output_dir=$output_dir \
                --decoder_layers=24 \
                --batch_size=32 \
                --num_gpus=2 \
                --num_beams=$num_beams \
                --edit_distance_extra_len=$edit_distance_extra_len \
                --edit_distance_weight=$edit_distance_weight \
                --length_penalty=$length_penalty \
                --$beam_sort_linear_ed \
                --$beam_final_score_normalize_ed \
                --dict_matching \

        done
    done
done
